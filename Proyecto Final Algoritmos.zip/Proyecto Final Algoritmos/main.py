
import argparse
import os
from pathlib import Path

from negocio import Inventario, ErrorDatos
from correos import crear_cotizacion, enviar_correo, configurado, correo_valido

BASE = Path(__file__).resolve().parent


def mostrar(registros):
    if not registros:
        print('No hay registros.')
        return
    for elemento in registros:
        print(' | '.join(f'{campo}: {valor}' for campo, valor in elemento.items()))


def pedir(mensaje):
    return input(mensaje + ': ').strip()


def consola(db):
    """Menú de consola con los cinco bloques indicados en el documento."""
    while True:
        print('\n=== SISTEMA DE INVENTARIO ===')
        print('1. Productos')
        print('2. Clientes')
        print('3. Pedidos')
        print('4. Informes')
        print('5. Varios')
        print('0. Salir')
        opcion = pedir('Opción')
        if opcion == '0':
            print('Hasta luego.')
            break
        try:
            if opcion == '1':
                print('\n1. Agregar  2. Editar  3. Eliminar  4. Listar  5. Enviar cotización')
                accion = pedir('Opción de productos')
                if accion == '1':
                    codigo = db.agregar_producto(pedir('Nombre'), pedir('Precio'), pedir('Existencia'))
                    print(f'Producto guardado con código {codigo}.')
                elif accion == '2':
                    db.editar_producto(pedir('Código'), pedir('Nuevo nombre'), pedir('Nuevo precio'), pedir('Existencia'))
                    print('Producto actualizado.')
                elif accion == '3':
                    db.eliminar_producto(pedir('Código'))
                    print('Producto eliminado.')
                elif accion == '4':
                    mostrar(db.productos())
                elif accion == '5':
                    nombre = pedir('Nombre del cliente')
                    email = pedir('Correo del cliente')
                    if not correo_valido(email):
                        raise ErrorDatos('El correo del cliente no es válido.')
                    codigo = int(pedir('Código del producto'))
                    producto = next((p for p in db.productos() if p['id'] == codigo), None)
                    if producto is None:
                        raise ErrorDatos('El producto no existe.')
                    archivo = crear_cotizacion(nombre, producto['nombre'], producto['precio'], BASE / 'cotizaciones')
                    print(f'Cotización creada: {archivo}')
                    if configurado():
                        enviar_correo(email, 'Cotización de producto', 'Adjuntamos la cotización solicitada.', archivo)
                        print('Correo enviado correctamente.')
                    else:
                        print('Correo NO enviado: configura las variables SMTP.')
                else:
                    print('Opción no válida.')
            elif opcion == '2':
                print('\n1. Agregar  2. Editar  3. Eliminar  4. Listar')
                accion = pedir('Opción de clientes')
                if accion == '1':
                    codigo = db.agregar_cliente(pedir('Nombre'), pedir('NIT'), pedir('Dirección'))
                    print(f'Cliente registrado con código {codigo}.')
                elif accion == '2':
                    db.editar_cliente(pedir('Código'), pedir('Nombre'), pedir('NIT'), pedir('Dirección'))
                    print('Cliente actualizado.')
                elif accion == '3':
                    db.eliminar_cliente(pedir('Código'))
                    print('Cliente eliminado.')
                elif accion == '4':
                    mostrar(db.clientes())
                else:
                    print('Opción no válida.')
            elif opcion == '3':
                print('\n1. Agregar  2. Eliminar  3. Listar')
                accion = pedir('Opción de pedidos')
                if accion == '1':
                    codigo = db.agregar_pedido(pedir('Código de cliente'), pedir('Código de producto'), pedir('Cantidad'))
                    print(f'Pedido guardado con código {codigo}.')
                elif accion == '2':
                    db.eliminar_pedido(pedir('Código de pedido'))
                    print('Pedido eliminado y existencia devuelta.')
                elif accion == '3':
                    mostrar(db.pedidos())
                else:
                    print('Opción no válida.')
            elif opcion == '4':
                print('\n1. Total de ventas por cliente  2. Total de ventas por producto')
                accion = pedir('Opción de informe')
                if accion == '1':
                    datos = db.informe_clientes()
                elif accion == '2':
                    datos = db.informe_productos()
                else:
                    print('Opción no válida.')
                    continue
                if not datos:
                    print('Aún no existen ventas.')
                for codigo, nombre, total in datos:
                    print(f'{codigo} | {nombre} | Q{total:,.2f}')
            elif opcion == '5':
                print('\n1. Crear copia de seguridad de datos')
                if pedir('Opción') == '1':
                    copia = db.copia_seguridad()
                    print(f'Respaldo creado: {copia}')
                    coordinador = os.getenv('CORREO_COORDINADOR', '')
                    if coordinador and configurado():
                        enviar_correo(coordinador, 'Respaldo Inventario.xlsx',
                                      'Adjunto la copia de seguridad del inventario.', copia)
                        print('Correo enviado al coordinador.')
                    else:
                        print('Correo NO enviado: faltan los datos SMTP o el correo del coordinador.')
            else:
                print('Opción no válida.')
        except (ErrorDatos, ValueError, PermissionError, OSError, RuntimeError) as error:
            print('Aviso:', error)
        except Exception as error:
            print('Error inesperado:', error)


def main():
    parser = argparse.ArgumentParser(description='Sistema de productos, clientes y pedidos')
    parser.add_argument('--consola', action='store_true', help='Abre el menú en terminal')
    args = parser.parse_args()
    db = Inventario(BASE / 'Inventario.xlsx')
    if args.consola:
        consola(db)
    else:
        try:
            from interfaz import Aplicacion
            Aplicacion(db).mainloop()
        except ImportError as error:
            print('Tkinter no está disponible. Ejecuta con --consola.')
            print(error)


if __name__ == '__main__':
    main()
