## 1. Herramienta utilizada

Se utilizó ChatGPT (OpenAI) como apoyo durante el desarrollo del proyecto. El equipo consultó la herramienta para aclarar dudas, organizar algunas tareas y explorar distintas maneras de resolver aspectos específicos de la aplicación. Las respuestas sirvieron como orientación y se revisaron de acuerdo con las necesidades del proyecto; los integrantes tomaron las decisiones e hicieron el trabajo de implementación.

ChatGPT también se utilizó para considerar ideas de diseño para las interfaces, comprender ejemplos de programación y pensar en situaciones que podían revisarse durante las pruebas. El equipo adaptó las sugerencias pertinentes y se encargó de desarrollar, integrar y comprobar los componentes de la aplicación.

## 2. Prompts utilizados

Durante el proyecto se realizaron consultas sobre diferentes temas relacionados con el desarrollo, por ejemplo:

- Cómo organizar las tareas y establecer pasos para avanzar con la aplicación.
- Qué aspectos considerar para diseñar interfaces claras y distribuir sus elementos.
- Cómo implementar funciones específicas y comprender ejemplos de programación relacionados.
- Cómo interpretar errores o resolver dificultades surgidas durante el desarrollo.
- Qué casos podían incluirse en las pruebas para revisar el funcionamiento de la aplicación.
- Cómo describir y presentar en la documentación el trabajo realizado por el equipo.

Las respuestas de ChatGPT se tomaron como referencia. Los integrantes analizaron las sugerencias, eligieron las que resultaban útiles y las adaptaron al proyecto. El desarrollo y las decisiones finales estuvieron a cargo del equipo.

## 3. Aporte de los integrantes

- **Luis Angel Pérez:** realizó la conexión al correo y participó en las pruebas del sistema para revisar el funcionamiento de la aplicación.
- **Julio Escobar:** diseñó y desarrolló las interfaces de la aplicación.
- **Danilo Elias:** elaboró los diagramas para representar y explicar el proyecto.