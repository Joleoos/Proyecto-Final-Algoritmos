
import os
import re
import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).with_name(".env"))

from docx import Document
from docx.shared import Pt


def correo_valido(direccion):
    return bool(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', str(direccion).strip()))


def crear_cotizacion(cliente, producto, precio, carpeta='cotizaciones'):
    """Crea un archivo llamado cotización.docx en la carpeta indicada."""
    cliente = str(cliente).strip()
    producto = str(producto).strip()
    if not cliente or not producto:
        raise ValueError('El nombre del cliente y el producto son obligatorios.')
    ruta = Path(carpeta)
    ruta.mkdir(parents=True, exist_ok=True)
    archivo = ruta / 'cotización.docx'
    doc = Document()
    doc.add_heading('Cotización de producto', 0)
    doc.add_paragraph(f'Estimado {cliente}')
    doc.add_paragraph(f'El precio de nuestro producto {producto}')
    doc.add_paragraph(f'es Q{float(precio):,.2f}')
    doc.add_paragraph('Gracias por su interés.')
    estilos = doc.styles['Normal']
    estilos.font.name = 'Calibri'
    estilos.font.size = Pt(11)
    doc.save(archivo)
    return archivo


def configurado():
    obligatorias = ('CORREO_SMTP_HOST', 'CORREO_USUARIO', 'CORREO_CLAVE')
    return all(os.getenv(variable) for variable in obligatorias)


def enviar_correo(destinatario, asunto, mensaje, adjunto):
    """SMTP SSL (465) o STARTTLS (por ejemplo, 587)."""
    if not correo_valido(destinatario):
        raise ValueError('El correo de destino no es válido.')
    if not configurado():
        raise RuntimeError('Falta configurar las variables SMTP para enviar correos.')
    ruta = Path(adjunto)
    if not ruta.is_file():
        raise FileNotFoundError(f'No se encontró el archivo {ruta}.')

    servidor = os.environ['CORREO_SMTP_HOST']
    puerto = int(os.getenv('CORREO_SMTP_PUERTO', '465'))
    usuario = os.environ['CORREO_USUARIO']
    clave = os.environ['CORREO_CLAVE']
    remitente = os.getenv('CORREO_REMITENTE', usuario)

    carta = EmailMessage()
    carta['From'] = remitente
    carta['To'] = destinatario
    carta['Subject'] = asunto
    carta.set_content(mensaje)
    tipo = 'application'
    subtipo = 'vnd.openxmlformats-officedocument.wordprocessingml.document'
    if ruta.suffix.lower() == '.xlsx':
        subtipo = 'vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    carta.add_attachment(ruta.read_bytes(), maintype=tipo, subtype=subtipo,
                         filename=ruta.name)

    contexto = ssl.create_default_context()
    if puerto == 465:
        with smtplib.SMTP_SSL(servidor, puerto, context=contexto, timeout=20) as smtp:
            smtp.login(usuario, clave)
            smtp.send_message(carta)
    else:
        with smtplib.SMTP(servidor, puerto, timeout=20) as smtp:
            smtp.ehlo()
            smtp.starttls(context=contexto)
            smtp.ehlo()
            smtp.login(usuario, clave)
            smtp.send_message(carta)
    return True
