
from collections import defaultdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from shutil import copy2
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment


class ErrorDatos(ValueError):
    """Se produce cuando los datos ingresados no son válidos."""


def texto_obligatorio(valor, campo):
    valor = str(valor).strip()
    if not valor:
        raise ErrorDatos(f"El campo '{campo}' es obligatorio.")
    return valor


def entero_positivo(valor, campo, permitir_cero=False):
    try:
        numero = int(str(valor).strip())
    except (ValueError, TypeError):
        raise ErrorDatos(f"'{campo}' debe ser un número entero.") from None
    minimo = 0 if permitir_cero else 1
    if numero < minimo:
        raise ErrorDatos(f"'{campo}' debe ser mayor o igual que {minimo}.")
    return numero


def dinero(valor):
    try:
        numero = Decimal(str(valor).strip()).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError):
        raise ErrorDatos('El precio debe ser un número válido.') from None
    if not numero.is_finite() or numero < 0:
        raise ErrorDatos('El precio debe ser un número mayor o igual a cero.')
    return float(numero)


class Inventario:
    ENCABEZADOS = {
        'productos': ['id', 'nombre', 'precio', 'existencia'],
        'clientes': ['id', 'nombre', 'nit', 'direccion'],
        'pedidos': [
            'id', 'cliente_id', 'producto_id', 'nombre_cliente',
            'nombre_producto', 'cantidad_producto', 'valor_pedido'
        ],
    }

    def __init__(self, ruta='Inventario.xlsx'):
        self.ruta = Path(ruta)
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        if not self.ruta.exists():
            self._crear_archivo()
        else:
            wb = load_workbook(self.ruta, read_only=True)
            try:
                for hoja, encabezados in self.ENCABEZADOS.items():
                    if hoja not in wb.sheetnames:
                        raise ErrorDatos(f'Falta la hoja {hoja} en el Excel.')
                    fila = [c.value for c in next(wb[hoja].iter_rows(max_row=1))]
                    if fila != encabezados:
                        raise ErrorDatos(f'Los encabezados de la hoja {hoja} no son los esperados.')
            finally:
                wb.close()

    def _crear_archivo(self):
        wb = Workbook()
        wb.remove(wb.active)
        for nombre, campos in self.ENCABEZADOS.items():
            ws = wb.create_sheet(nombre)
            ws.append(campos)
            ws.freeze_panes = 'A2'
            ws.auto_filter.ref = f'A1:{chr(64 + len(campos))}1'
            for celda in ws[1]:
                celda.fill = PatternFill('solid', fgColor='17324D')
                celda.font = Font(bold=True, color='FFFFFF')
                celda.alignment = Alignment(horizontal='center')
            for col in range(1, len(campos) + 1):
                ws.column_dimensions[chr(64 + col)].width = (24 if col > 1 else 10)
        wb.save(self.ruta)
        wb.close()

    @staticmethod
    def _filas(ws):
        campos = [celda.value for celda in ws[1]]
        return [dict(zip(campos, valores)) for valores in
                ws.iter_rows(min_row=2, values_only=True) if valores[0] is not None]

    @staticmethod
    def _encontrar(ws, id_buscado):
        for fila in range(2, ws.max_row + 1):
            if ws.cell(fila, 1).value == id_buscado:
                return fila
        raise ErrorDatos(f'No existe el registro con código {id_buscado}.')

    @staticmethod
    def _siguiente_id(ws):
        codigos = [ws.cell(fila, 1).value for fila in range(2, ws.max_row + 1)]
        return max((int(c) for c in codigos if c is not None), default=0) + 1

    def _listar(self, nombre):
        wb = load_workbook(self.ruta, read_only=True, data_only=True)
        try:
            return self._filas(wb[nombre])
        finally:
            wb.close()

    def productos(self):
        return self._listar('productos')

    def clientes(self):
        return self._listar('clientes')

    def pedidos(self):
        return self._listar('pedidos')

    def agregar_producto(self, nombre, precio, existencia):
        nombre = texto_obligatorio(nombre, 'nombre')
        precio = dinero(precio)
        existencia = entero_positivo(existencia, 'existencia', permitir_cero=True)
        wb = load_workbook(self.ruta)
        try:
            ws = wb['productos']
            if any(p['nombre'].casefold() == nombre.casefold() for p in self._filas(ws)):
                raise ErrorDatos('Ya existe un producto con ese nombre.')
            codigo = self._siguiente_id(ws)
            ws.append([codigo, nombre, precio, existencia])
            ws.cell(ws.max_row, 3).number_format = '"Q"#,##0.00'
            wb.save(self.ruta)
            return codigo
        finally:
            wb.close()

    def editar_producto(self, codigo, nombre, precio, existencia):
        codigo = entero_positivo(codigo, 'código')
        nombre = texto_obligatorio(nombre, 'nombre')
        precio = dinero(precio)
        existencia = entero_positivo(existencia, 'existencia', permitir_cero=True)
        wb = load_workbook(self.ruta)
        try:
            ws = wb['productos']
            fila = self._encontrar(ws, codigo)
            if any(p['id'] != codigo and p['nombre'].casefold() == nombre.casefold()
                   for p in self._filas(ws)):
                raise ErrorDatos('Ya existe otro producto con ese nombre.')
            for col, valor in enumerate((nombre, precio, existencia), 2):
                ws.cell(fila, col).value = valor
            wb.save(self.ruta)
        finally:
            wb.close()

    def eliminar_producto(self, codigo):
        codigo = entero_positivo(codigo, 'código')
        wb = load_workbook(self.ruta)
        try:
            if any(p['producto_id'] == codigo for p in self._filas(wb['pedidos'])):
                raise ErrorDatos('No se puede borrar un producto que aparece en pedidos.')
            ws = wb['productos']
            ws.delete_rows(self._encontrar(ws, codigo))
            wb.save(self.ruta)
        finally:
            wb.close()

    def agregar_cliente(self, nombre, nit, direccion):
        nombre = texto_obligatorio(nombre, 'nombre')
        nit = texto_obligatorio(nit, 'NIT')
        direccion = texto_obligatorio(direccion, 'dirección')
        wb = load_workbook(self.ruta)
        try:
            ws = wb['clientes']
            if any(str(c['nit']).casefold() == nit.casefold() for c in self._filas(ws)):
                raise ErrorDatos('Ya existe un cliente con ese NIT.')
            codigo = self._siguiente_id(ws)
            ws.append([codigo, nombre, nit, direccion])
            wb.save(self.ruta)
            return codigo
        finally:
            wb.close()

    def editar_cliente(self, codigo, nombre, nit, direccion):
        codigo = entero_positivo(codigo, 'código')
        nombre = texto_obligatorio(nombre, 'nombre')
        nit = texto_obligatorio(nit, 'NIT')
        direccion = texto_obligatorio(direccion, 'dirección')
        wb = load_workbook(self.ruta)
        try:
            ws = wb['clientes']
            fila = self._encontrar(ws, codigo)
            if any(c['id'] != codigo and str(c['nit']).casefold() == nit.casefold()
                   for c in self._filas(ws)):
                raise ErrorDatos('Ya existe otro cliente con ese NIT.')
            for col, valor in enumerate((nombre, nit, direccion), 2):
                ws.cell(fila, col).value = valor
            wb.save(self.ruta)
        finally:
            wb.close()

    def eliminar_cliente(self, codigo):
        codigo = entero_positivo(codigo, 'código')
        wb = load_workbook(self.ruta)
        try:
            if any(p['cliente_id'] == codigo for p in self._filas(wb['pedidos'])):
                raise ErrorDatos('No se puede borrar un cliente que aparece en pedidos.')
            ws = wb['clientes']
            ws.delete_rows(self._encontrar(ws, codigo))
            wb.save(self.ruta)
        finally:
            wb.close()

    def agregar_pedido(self, cliente_id, producto_id, cantidad):
        cliente_id = entero_positivo(cliente_id, 'código del cliente')
        producto_id = entero_positivo(producto_id, 'código del producto')
        cantidad = entero_positivo(cantidad, 'cantidad')
        wb = load_workbook(self.ruta)
        try:
            cl = wb['clientes']
            pr = wb['productos']
            nombre_cliente = cl.cell(self._encontrar(cl, cliente_id), 2).value
            fila_producto = self._encontrar(pr, producto_id)
            nombre_producto = pr.cell(fila_producto, 2).value
            precio = Decimal(str(pr.cell(fila_producto, 3).value))
            stock = int(pr.cell(fila_producto, 4).value)
            if cantidad > stock:
                raise ErrorDatos(f'Existencia insuficiente. Disponibles: {stock}.')
            valor = float((precio * cantidad).quantize(Decimal('0.01')))
            pedidos = wb['pedidos']
            codigo = self._siguiente_id(pedidos)
            pedidos.append([codigo, cliente_id, producto_id, nombre_cliente,
                            nombre_producto, cantidad, valor])
            pedidos.cell(pedidos.max_row, 7).number_format = '"Q"#,##0.00'
            pr.cell(fila_producto, 4).value = stock - cantidad
            wb.save(self.ruta)
            return codigo
        finally:
            wb.close()

    def eliminar_pedido(self, codigo):
        codigo = entero_positivo(codigo, 'código')
        wb = load_workbook(self.ruta)
        try:
            ws = wb['pedidos']
            fila = self._encontrar(ws, codigo)
            producto_id = ws.cell(fila, 3).value
            cantidad = int(ws.cell(fila, 6).value)
            pr = wb['productos']
            fila_producto = self._encontrar(pr, producto_id)
            pr.cell(fila_producto, 4).value += cantidad
            ws.delete_rows(fila)
            wb.save(self.ruta)
        finally:
            wb.close()

    def informe_clientes(self):
        acumulado = defaultdict(lambda: Decimal('0'))
        for pedido in self.pedidos():
            clave = (pedido['cliente_id'], pedido['nombre_cliente'])
            acumulado[clave] += Decimal(str(pedido['valor_pedido']))
        return sorted([(codigo, nombre, float(total)) for (codigo, nombre), total
                       in acumulado.items()], key=lambda item: (-item[2], item[1]))

    def informe_productos(self):
        acumulado = defaultdict(lambda: Decimal('0'))
        for pedido in self.pedidos():
            clave = (pedido['producto_id'], pedido['nombre_producto'])
            acumulado[clave] += Decimal(str(pedido['valor_pedido']))
        return sorted([(codigo, nombre, float(total)) for (codigo, nombre), total
                       in acumulado.items()], key=lambda item: (-item[2], item[1]))

    def copia_seguridad(self, carpeta=None):
        destino = Path(carpeta) if carpeta else self.ruta.parent / 'respaldos'
        destino.mkdir(parents=True, exist_ok=True)
        marca = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        ruta = destino / f'Inventario_respaldo_{marca}.xlsx'
        copy2(self.ruta, ruta)
        return ruta
