import os
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

from negocio import ErrorDatos
from correos import crear_cotizacion, enviar_correo, correo_valido, configurado


class Aplicacion(tk.Tk):
    def __init__(self, inventario):
        super().__init__()
        self.db = inventario
        self.title('Sistema de inventario')
        self.geometry('1000x650')
        self.minsize(900, 600)
        self._estilos()
        self._menu()
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)
        self.productos_tab = ttk.Frame(self.notebook, padding=8)
        self.clientes_tab = ttk.Frame(self.notebook, padding=8)
        self.pedidos_tab = ttk.Frame(self.notebook, padding=8)
        self.informes_tab = ttk.Frame(self.notebook, padding=8)
        self.varios_tab = ttk.Frame(self.notebook, padding=8)
        for titulo, tab in [('Productos', self.productos_tab), ('Clientes', self.clientes_tab),
                            ('Pedidos', self.pedidos_tab), ('Informes', self.informes_tab),
                            ('Varios', self.varios_tab)]:
            self.notebook.add(tab, text=titulo)
        self._tab_productos()
        self._tab_clientes()
        self._tab_pedidos()
        self._tab_informes()
        self._tab_varios()
        self.refrescar()

    def _estilos(self):
        estilo = ttk.Style(self)
        estilo.configure('Titulo.TLabel', font=('Arial', 11, 'bold'))
        estilo.configure('Treeview', rowheight=24)

    def _menu(self):
        barra = tk.Menu(self)
        archivo = tk.Menu(barra, tearoff=0)
        archivo.add_command(label='Salir', command=self.destroy)
        barra.add_cascade(label='Archivo', menu=archivo)
        self.config(menu=barra)

    @staticmethod
    def _titulo(marco, texto, descripcion=None):
        ttk.Label(marco, text=texto, style='Titulo.TLabel').pack(anchor='w', pady=(0, 8))

    @staticmethod
    def _tabla(padre, columnas, anchos=None):
        contenedor = ttk.Frame(padre)
        contenedor.pack(fill='both', expand=True, pady=(6, 8))
        tabla = ttk.Treeview(contenedor, columns=columnas, show='headings', height=6)
        for indice, nombre in enumerate(columnas):
            tabla.heading(nombre, text=nombre.replace('_', ' ').title())
            tabla.column(nombre, width=(anchos[indice] if anchos else 130), anchor='w')
        barra = ttk.Scrollbar(contenedor, command=tabla.yview)
        tabla.configure(yscrollcommand=barra.set)
        barra.pack(side='right', fill='y')
        tabla.pack(side='left', fill='both', expand=True)
        return tabla

    @staticmethod
    def _campo(padre, etiqueta, variable, columna, fila):
        ttk.Label(padre, text=etiqueta).grid(row=fila, column=columna, sticky='w', padx=5, pady=3)
        entrada = ttk.Entry(padre, textvariable=variable, width=28)
        entrada.grid(row=fila + 1, column=columna, sticky='ew', padx=5, pady=(0, 9))
        return entrada

    def _manejar(self, tarea, aviso='Operación realizada.'):
        try:
            tarea()
            self.refrescar()
            messagebox.showinfo('Éxito', aviso, parent=self)
        except (ErrorDatos, ValueError, OSError, PermissionError) as error:
            messagebox.showerror('Aviso', str(error), parent=self)
        except Exception as error:
            messagebox.showerror('Error', f'No se pudo completar: {error}', parent=self)

    def _codigo_elegido(self, tabla):
        seleccion = tabla.selection()
        if not seleccion:
            raise ErrorDatos('Selecciona primero una fila de la tabla.')
        return int(tabla.item(seleccion[0], 'values')[0])

    def _tab_productos(self):
        panel = self.productos_tab
        self._titulo(panel, 'Gestión de productos', 'Agrega, edita y elimina artículos; selecciona uno para enviar su cotización.')
        self.tabla_productos = self._tabla(panel, ('id', 'nombre', 'precio', 'existencia'), (70, 320, 140, 120))
        self.tabla_productos.bind('<<TreeviewSelect>>', self._seleccionar_producto)
        formulario = ttk.Frame(panel)
        formulario.pack(fill='x')
        self.p_nombre = tk.StringVar()
        self.p_precio = tk.StringVar()
        self.p_stock = tk.StringVar()
        for columna, (nombre, variable) in enumerate((('Nombre', self.p_nombre), ('Precio Q', self.p_precio), ('Existencia', self.p_stock))):
            self._campo(formulario, nombre, variable, columna, 0)
            formulario.columnconfigure(columna, weight=1)
        botones = ttk.Frame(panel)
        botones.pack(fill='x', pady=(8, 0))
        ttk.Button(botones, text='Agregar producto', command=lambda: self._manejar(
            lambda: self.db.agregar_producto(self.p_nombre.get(), self.p_precio.get(), self.p_stock.get()))).pack(side='left', padx=4)
        ttk.Button(botones, text='Guardar cambios', command=lambda: self._manejar(
            lambda: self.db.editar_producto(self._codigo_elegido(self.tabla_productos),
                                            self.p_nombre.get(), self.p_precio.get(), self.p_stock.get()))).pack(side='left', padx=4)
        ttk.Button(botones, text='Eliminar', command=self._eliminar_producto).pack(side='left', padx=4)
        ttk.Button(botones, text='Enviar cotización', command=self._cotizacion).pack(side='left', padx=4)
        ttk.Button(botones, text='Limpiar', command=lambda: [v.set('') for v in (self.p_nombre, self.p_precio, self.p_stock)]).pack(side='left', padx=4)

    def _seleccionar_producto(self, _evento):
        if self.tabla_productos.selection():
            datos = self.tabla_productos.item(self.tabla_productos.selection()[0], 'values')
            for variable, valor in zip((self.p_nombre, self.p_precio, self.p_stock), datos[1:]):
                variable.set(valor)

    def _eliminar_producto(self):
        try:
            codigo = self._codigo_elegido(self.tabla_productos)
        except ErrorDatos as error:
            messagebox.showwarning('Aviso', str(error), parent=self)
            return
        if messagebox.askyesno('Confirmación', '¿Eliminar este producto?', parent=self):
            self._manejar(lambda: self.db.eliminar_producto(codigo))

    def _cotizacion(self):
        try:
            codigo = self._codigo_elegido(self.tabla_productos)
            producto = next(p for p in self.db.productos() if p['id'] == codigo)
        except (ErrorDatos, StopIteration) as error:
            messagebox.showerror('Aviso', str(error) or 'Producto no disponible.', parent=self)
            return
        cliente = simpledialog.askstring('Cotización', 'Nombre del cliente:', parent=self)
        if cliente is None:
            return
        destino = simpledialog.askstring('Cotización', 'Correo del cliente:', parent=self)
        if destino is None:
            return
        if not cliente.strip() or not correo_valido(destino):
            messagebox.showerror('Aviso', 'Ingresa un nombre y un correo válido.', parent=self)
            return
        try:
            ruta = crear_cotizacion(cliente, producto['nombre'], producto['precio'],
                                    self.db.ruta.parent / 'cotizaciones')
            if not configurado():
                messagebox.showwarning('Cotización creada',
                    f'Se guardó el archivo en:\n{ruta}\n\nNo se envió el correo: configura SMTP en tu computadora.', parent=self)
                return
            enviar_correo(destino, 'Cotización solicitada',
                f'Hola {cliente}, adjuntamos la cotización solicitada.', ruta)
            messagebox.showinfo('Correo enviado', f'Se envió la cotización a {destino}.', parent=self)
        except Exception as error:
            messagebox.showerror('Aviso', f'Cotización generada o envío interrumpido: {error}', parent=self)

    def _tab_clientes(self):
        panel = self.clientes_tab
        self._titulo(panel, 'Gestión de clientes', 'Registra nombre, NIT y dirección de cada cliente.')
        self.tabla_clientes = self._tabla(panel, ('id', 'nombre', 'nit', 'direccion'), (70, 270, 130, 330))
        self.tabla_clientes.bind('<<TreeviewSelect>>', self._seleccionar_cliente)
        formulario = ttk.Frame(panel)
        formulario.pack(fill='x')
        self.c_nombre = tk.StringVar()
        self.c_nit = tk.StringVar()
        self.c_direccion = tk.StringVar()
        for columna, (nombre, variable) in enumerate((('Nombre', self.c_nombre), ('NIT', self.c_nit), ('Dirección', self.c_direccion))):
            self._campo(formulario, nombre, variable, columna, 0)
            formulario.columnconfigure(columna, weight=1)
        botones = ttk.Frame(panel)
        botones.pack(fill='x', pady=(8, 0))
        ttk.Button(botones, text='Agregar cliente', command=lambda: self._manejar(
            lambda: self.db.agregar_cliente(self.c_nombre.get(), self.c_nit.get(), self.c_direccion.get()))).pack(side='left', padx=4)
        ttk.Button(botones, text='Guardar cambios', command=lambda: self._manejar(
            lambda: self.db.editar_cliente(self._codigo_elegido(self.tabla_clientes),
                                          self.c_nombre.get(), self.c_nit.get(), self.c_direccion.get()))).pack(side='left', padx=4)
        ttk.Button(botones, text='Eliminar', command=self._eliminar_cliente).pack(side='left', padx=4)
        ttk.Button(botones, text='Limpiar', command=lambda: [v.set('') for v in (self.c_nombre, self.c_nit, self.c_direccion)]).pack(side='left', padx=4)

    def _seleccionar_cliente(self, _evento):
        if self.tabla_clientes.selection():
            datos = self.tabla_clientes.item(self.tabla_clientes.selection()[0], 'values')
            for variable, valor in zip((self.c_nombre, self.c_nit, self.c_direccion), datos[1:]):
                variable.set(valor)

    def _eliminar_cliente(self):
        try:
            codigo = self._codigo_elegido(self.tabla_clientes)
        except ErrorDatos as error:
            messagebox.showwarning('Aviso', str(error), parent=self)
            return
        if messagebox.askyesno('Confirmación', '¿Eliminar este cliente?', parent=self):
            self._manejar(lambda: self.db.eliminar_cliente(codigo))

    def _tab_pedidos(self):
        panel = self.pedidos_tab
        self._titulo(panel, 'Pedidos y ventas', 'Un pedido reduce las existencias y al eliminarlo las devuelve.')
        self.tabla_pedidos = self._tabla(panel, ('id', 'nombre_cliente', 'nombre_producto', 'cantidad_producto', 'valor_pedido'), (65, 220, 240, 160, 140))
        formulario = ttk.Frame(panel)
        formulario.pack(fill='x')
        self.combo_cliente = ttk.Combobox(formulario, state='readonly', width=35)
        self.combo_producto = ttk.Combobox(formulario, state='readonly', width=35)
        self.cantidad = tk.StringVar(value='1')
        for indice, titulo in enumerate(('Cliente', 'Producto', 'Cantidad')):
            ttk.Label(formulario, text=titulo).grid(row=0, column=indice, sticky='w', padx=5)
            formulario.columnconfigure(indice, weight=1)
        self.combo_cliente.grid(row=1, column=0, sticky='ew', padx=5, pady=8)
        self.combo_producto.grid(row=1, column=1, sticky='ew', padx=5, pady=8)
        ttk.Entry(formulario, textvariable=self.cantidad, width=15).grid(row=1, column=2, sticky='ew', padx=5, pady=8)
        botones = ttk.Frame(panel)
        botones.pack(fill='x')
        ttk.Button(botones, text='Agregar pedido', command=lambda: self._manejar(self._agregar_pedido)).pack(side='left', padx=4)
        ttk.Button(botones, text='Eliminar pedido seleccionado', command=self._eliminar_pedido).pack(side='left', padx=4)
        ttk.Button(botones, text='Actualizar', command=self.refrescar).pack(side='left', padx=4)

    def _agregar_pedido(self):
        cliente = self.combo_cliente.get()
        producto = self.combo_producto.get()
        if not cliente or not producto:
            raise ErrorDatos('Selecciona un cliente y un producto.')
        self.db.agregar_pedido(int(cliente.split(' | ')[0]),
                               int(producto.split(' | ')[0]), self.cantidad.get())

    def _eliminar_pedido(self):
        try:
            codigo = self._codigo_elegido(self.tabla_pedidos)
        except ErrorDatos as error:
            messagebox.showwarning('Aviso', str(error), parent=self)
            return
        if messagebox.askyesno('Confirmación', '¿Eliminar pedido y devolver la existencia?', parent=self):
            self._manejar(lambda: self.db.eliminar_pedido(codigo))

    def _tab_informes(self):
        panel = self.informes_tab
        self._titulo(panel, 'Informes de ventas', 'Totales calculados a partir de los pedidos registrados.')
        ttk.Label(panel, text='Total de ventas por cliente', style='Titulo.TLabel').pack(anchor='w')
        self.tabla_info_clientes = self._tabla(panel, ('id', 'nombre', 'total_ventas'))
        ttk.Label(panel, text='Total de ventas por producto', style='Titulo.TLabel').pack(anchor='w')
        self.tabla_info_productos = self._tabla(panel, ('id', 'nombre', 'total_ventas'))
        ttk.Button(panel, text='Actualizar informes', command=self.refrescar).pack(anchor='w')

    def _tab_varios(self):
        panel = self.varios_tab
        self._titulo(panel, 'Copias de seguridad', 'Conserva una copia íntegra de Inventario.xlsx y envíala al coordinador del grupo.')
        ttk.Label(panel, text='Archivo de datos: ' + str(self.db.ruta)).pack(anchor='w', pady=(0, 12))
        ttk.Label(panel, text='Correo del coordinador:').pack(anchor='w')
        ttk.Label(panel, text=os.getenv('CORREO_COORDINADOR') or 'Sin configurar').pack(anchor='w', pady=(4, 15))
        ttk.Button(panel, text='Crear copia de seguridad y enviarla', command=self._respaldo).pack(anchor='w')
        ttk.Label(panel, text='Si no configuras SMTP, la copia se crea localmente sin enviarse.').pack(anchor='w', pady=(15, 0))

    def _respaldo(self):
        try:
            archivo = self.db.copia_seguridad()
            correo = os.getenv('CORREO_COORDINADOR', '').strip()
            if not correo or not configurado():
                messagebox.showwarning('Respaldo guardado',
                    f'Se creó la copia:\n{archivo}\n\nNo se envió: falta configurar el coordinador o SMTP.', parent=self)
                return
            enviar_correo(correo, 'Copia de seguridad - Inventario',
                          'Adjunto el respaldo completo de Inventario.xlsx.', archivo)
            messagebox.showinfo('Respaldo enviado', f'Copia guardada y enviada a {correo}.', parent=self)
        except Exception as error:
            messagebox.showerror('Aviso', f'No se completó el envío del respaldo: {error}', parent=self)

    def refrescar(self):
        tablas = [
            (self.tabla_productos, self.db.productos(), ('id', 'nombre', 'precio', 'existencia')),
            (self.tabla_clientes, self.db.clientes(), ('id', 'nombre', 'nit', 'direccion')),
            (self.tabla_pedidos, self.db.pedidos(), ('id', 'nombre_cliente', 'nombre_producto', 'cantidad_producto', 'valor_pedido')),
        ]
        for tabla, registros, campos in tablas:
            for item in tabla.get_children():
                tabla.delete(item)
            for registro in registros:
                tabla.insert('', 'end', values=[registro[campo] for campo in campos])
        clientes = self.db.clientes()
        productos = self.db.productos()
        self.combo_cliente['values'] = [f"{c['id']} | {c['nombre']}" for c in clientes]
        self.combo_producto['values'] = [f"{p['id']} | {p['nombre']} (Q{p['precio']:.2f}, stock {p['existencia']})" for p in productos]
        for tabla, datos in ((self.tabla_info_clientes, self.db.informe_clientes()),
                             (self.tabla_info_productos, self.db.informe_productos())):
            for item in tabla.get_children():
                tabla.delete(item)
            for codigo, nombre, total in datos:
                tabla.insert('', 'end', values=(codigo, nombre, f'Q{total:,.2f}'))
