"""Pruebas unitarias para productos, clientes, pedidos, reportes y respaldos."""
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from openpyxl import load_workbook

from negocio import Inventario, ErrorDatos
from correos import crear_cotizacion, correo_valido, enviar_correo, configurado
from docx import Document


class PruebasInventario(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.ruta = Path(self.temporal.name)
        self.db = Inventario(self.ruta / 'Inventario.xlsx')

    def tearDown(self):
        self.temporal.cleanup()

    def test_01_crea_excel_con_tres_hojas(self):
        libro = load_workbook(self.db.ruta)
        self.assertEqual(libro.sheetnames, ['productos', 'clientes', 'pedidos'])
        libro.close()

    def test_02_agregar_y_listar_productos(self):
        codigo = self.db.agregar_producto('Teclado', 125.50, 9)
        self.assertEqual(codigo, 1)
        self.assertEqual(self.db.productos()[0]['nombre'], 'Teclado')

    def test_03_editar_producto(self):
        codigo = self.db.agregar_producto('Mouse', 65, 12)
        self.db.editar_producto(codigo, 'Mouse Gamer', 95, 8)
        self.assertEqual(self.db.productos()[0]['precio'], 95)
        self.assertEqual(self.db.productos()[0]['nombre'], 'Mouse Gamer')

    def test_04_eliminar_producto(self):
        codigo = self.db.agregar_producto('Audífonos', 110, 3)
        self.db.eliminar_producto(codigo)
        self.assertEqual(self.db.productos(), [])

    def test_05_cliente_agregar_editar_eliminar(self):
        codigo = self.db.agregar_cliente('Ana López', '12345', 'Jalapa')
        self.assertEqual(self.db.clientes()[0]['nombre'], 'Ana López')
        self.db.editar_cliente(codigo, 'Ana María', '12345', 'Guatemala')
        self.assertEqual(self.db.clientes()[0]['direccion'], 'Guatemala')
        self.db.eliminar_cliente(codigo)
        self.assertEqual(self.db.clientes(), [])

    def test_06_pedido_descuenta_existencias(self):
        cliente = self.db.agregar_cliente('Pablo', 'CF', 'Jalapa')
        producto = self.db.agregar_producto('Control', '150.25', 5)
        codigo = self.db.agregar_pedido(cliente, producto, 2)
        self.assertEqual(codigo, 1)
        self.assertEqual(self.db.productos()[0]['existencia'], 3)
        self.assertEqual(self.db.pedidos()[0]['valor_pedido'], 300.50)

    def test_07_eliminar_pedido_devuelve_existencias(self):
        cliente = self.db.agregar_cliente('Sara', '11', 'Jalapa')
        producto = self.db.agregar_producto('Cable', 25, 4)
        pedido = self.db.agregar_pedido(cliente, producto, 3)
        self.db.eliminar_pedido(pedido)
        self.assertEqual(self.db.productos()[0]['existencia'], 4)
        self.assertEqual(self.db.pedidos(), [])

    def test_08_informes(self):
        cliente = self.db.agregar_cliente('Elena', '331', 'Zona 1')
        producto = self.db.agregar_producto('Memoria USB', 40, 10)
        self.db.agregar_pedido(cliente, producto, 2)
        self.db.agregar_pedido(cliente, producto, 1)
        self.assertEqual(self.db.informe_clientes(), [(cliente, 'Elena', 120.0)])
        self.assertEqual(self.db.informe_productos(), [(producto, 'Memoria USB', 120.0)])

    def test_09_no_permite_pedido_sin_stock(self):
        cliente = self.db.agregar_cliente('Jose', '45', 'Jalapa')
        producto = self.db.agregar_producto('Monitor', 1200, 1)
        with self.assertRaises(ErrorDatos):
            self.db.agregar_pedido(cliente, producto, 3)
        self.assertEqual(self.db.pedidos(), [])

    def test_10_no_permite_borrar_con_ventas(self):
        cliente = self.db.agregar_cliente('Marta', '25', 'Jalapa')
        producto = self.db.agregar_producto('Pantalla', 900, 5)
        self.db.agregar_pedido(cliente, producto, 1)
        with self.assertRaises(ErrorDatos):
            self.db.eliminar_cliente(cliente)
        with self.assertRaises(ErrorDatos):
            self.db.eliminar_producto(producto)

    def test_11_valida_datos_y_duplicados(self):
        self.db.agregar_producto('Teclado', 200, 2)
        with self.assertRaises(ErrorDatos):
            self.db.agregar_producto('teclado', 220, 2)
        with self.assertRaises(ErrorDatos):
            self.db.agregar_producto('Otro', -1, 2)
        with self.assertRaises(ErrorDatos):
            self.db.agregar_cliente('', '123', 'Jalapa')

    def test_12_respaldo_integral(self):
        self.db.agregar_producto('Micrófono', 200, 2)
        ruta = self.db.copia_seguridad()
        self.assertTrue(ruta.is_file())
        libro = load_workbook(ruta)
        self.assertEqual(libro.sheetnames, ['productos', 'clientes', 'pedidos'])
        self.assertEqual(libro['productos']['B2'].value, 'Micrófono')
        libro.close()

    def test_13_cotizacion_word(self):
        archivo = crear_cotizacion('Luis', 'Laptop', 4999.99, self.ruta / 'cotizaciones')
        self.assertEqual(archivo.name, 'cotización.docx')
        texto = '\n'.join(p.text for p in Document(archivo).paragraphs)
        self.assertIn('Estimado Luis', texto)
        self.assertIn('producto Laptop', texto)
        self.assertIn('Q4,999.99', texto)

    def test_14_validacion_correo(self):
        self.assertTrue(correo_valido('cliente@ejemplo.com'))
        self.assertFalse(correo_valido('cliente-sin-arroba'))

    def test_15_envio_email_simulado_sin_red(self):
        adjunto = crear_cotizacion('Lucía', 'Mouse', 50, self.ruta)
        datos = {'CORREO_SMTP_HOST': 'smtp.ejemplo.com', 'CORREO_SMTP_PUERTO': '465',
                 'CORREO_USUARIO': 'sender@ejemplo.com', 'CORREO_CLAVE': 'simulada'}
        with patch.dict(os.environ, datos), patch('correos.smtplib.SMTP_SSL') as conexion:
            self.assertTrue(configurado())
            self.assertTrue(enviar_correo('destino@ejemplo.com', 'Cotización', 'Adjunto', adjunto))
            conexion.return_value.__enter__.return_value.send_message.assert_called_once()


if __name__ == '__main__':
    unittest.main()
